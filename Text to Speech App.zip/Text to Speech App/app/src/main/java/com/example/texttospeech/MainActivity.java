package com.example.texttospeech;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import com.example.texttospeech.databinding.ActivityMainBinding;
import android.view.WindowManager;

public class MainActivity extends AppCompatActivity {
    // Variables
    // ================================================================================
    // ================================================================================
    private ActivityMainBinding binding;


    // onCreate
    // ================================================================================
    // ================================================================================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Run Parent Class's onCreate Method
        super.onCreate(savedInstanceState);

        //Inflate Activity's UI
        binding = ActivityMainBinding.inflate(getLayoutInflater());

        //Set Content View
        setContentView(binding.getRoot());

        //Set Theme
        SetTheme();

        //Set Soft Input Mode
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }


    // Set Theme
    // ================================================================================
    // ================================================================================
    public void SetTheme(){
        //Initialize Settings Object
        UserSettings settings = (UserSettings)getApplication();

        //Setup Settings Object
        settings.SetUp();

        //Get Theme
        String theme = settings.getString(UserSettings.CUSTOM_THEME, UserSettings.DEFAULT_THEME);

        //Set Theme
        AppCompatDelegate.setDefaultNightMode(theme.equals(UserSettings.DEFAULT_THEME) ? AppCompatDelegate.MODE_NIGHT_NO : AppCompatDelegate.MODE_NIGHT_YES);
    }
}