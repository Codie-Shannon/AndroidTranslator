package com.example.texttospeech;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class HeaderFragment extends Fragment {
    // Useless
    // ================================================================================
    // ================================================================================
    public HeaderFragment() { /* Required empty public constructor */ }


    // New Instance
    // ================================================================================
    // ================================================================================
    public static HeaderFragment newInstance() { return new HeaderFragment(); }


    // onCreate
    // ================================================================================
    // ================================================================================
    @Override
    public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); }


    // onCreateView
    // ================================================================================
    // ================================================================================
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_header, container, false);

        // Setup
        Setup(rootView);

        // Return RootView
        return rootView;
    }


    // Setup
    // ================================================================================
    // ================================================================================
    public void Setup(View rootview) {
        // Set Fragments Header Variable
        Fragments.header = rootview.findViewById(R.id.txtHeader);

        //Set Back Button
        Fragments.SetBackButton(((MainActivity)getActivity()).getSupportFragmentManager(), getParentFragmentManager(), Fragments.getImageButton(rootview, R.id.btnBack), R.id.fragMain, InputFragment.class);
    }
}