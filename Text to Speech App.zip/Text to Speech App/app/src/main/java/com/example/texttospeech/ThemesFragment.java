package com.example.texttospeech;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class ThemesFragment extends Fragment {
    // region Variables
    // Themes List
    // ================================================================================
    // ================================================================================
    List<CheckBoxes> themesList = new ArrayList<CheckBoxes>();


    // Settings
    // ================================================================================
    // ================================================================================
    private UserSettings settings;
    // endregion Variables



    // Useless
    // ================================================================================
    // ================================================================================
    public ThemesFragment() { /* Required empty public constructor */ }



    // New Instance
    // ================================================================================
    // ================================================================================
    public static ThemesFragment newInstance() { return new ThemesFragment(); }



    // onCreate
    // ================================================================================
    // ================================================================================
    @Override
    public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); }



    // onCreateView
    // ================================================================================
    // ================================================================================
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_themes, container, false);

        // Setup
        Setup(rootView);

        // Return RootView
        return rootView;
    }



    // region Setup
    // Setup
    // ================================================================================
    // ================================================================================
    public void Setup(View rootview){
        //Setup Settings
        SetupSettings();

        //Setup Themes
        SetupThemes(rootview);
    }


    // Setup Settings
    // ================================================================================
    // ================================================================================
    public void SetupSettings(){
        //Set Settings Object
        settings = (UserSettings)getActivity().getApplication();

        //Setup Settings Object
        settings.SetUp();
    }


    // Setup Themes
    // ================================================================================
    // ================================================================================
    public void SetupThemes(View rootview){
        //Add Themes to List
        themesList.add(new CheckBoxes(UserSettings.LIGHT_THEME, UserSettings.CUSTOM_THEME, rootview.findViewById(R.id.btnLight), rootview.findViewById(R.id.cbLight), UserSettings.DEFAULT_THEME));
        themesList.add(new CheckBoxes(UserSettings.DARK_THEME, UserSettings.CUSTOM_THEME, rootview.findViewById(R.id.btnDark), rootview.findViewById(R.id.cbDark), UserSettings.DEFAULT_THEME));

        //Setup CheckBoxes
        CheckBoxes.Setup("themes", themesList, settings, UserSettings.CUSTOM_THEME, UserSettings.DEFAULT_THEME);
    }
    // endregion Setup
}