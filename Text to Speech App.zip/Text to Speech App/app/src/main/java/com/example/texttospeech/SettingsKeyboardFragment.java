package com.example.texttospeech;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class SettingsKeyboardFragment extends Fragment {
    // region Variables
    // Radio Group
    // ================================================================================
    // ================================================================================
    private RadioGroup group;


    // Settings
    // ================================================================================
    // ================================================================================
    private UserSettings settings;
    // endregion Variables



    // Useless
    // ================================================================================
    // ================================================================================
    public SettingsKeyboardFragment() { /* Required empty public constructor */ }



    // New Instance
    // ================================================================================
    // ================================================================================
    public static SettingsKeyboardFragment newInstance() { return new SettingsKeyboardFragment(); }



    // onCreate
    // ================================================================================
    // ================================================================================
    @Override
    public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); }



    // onCreateView
    // ================================================================================
    // ================================================================================
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_settings_keyboard, container, false);

        // Setup
        Setup(rootView);

        // Return RootView
        return rootView;
    }



    // region Setup
    // Setup
    // ================================================================================
    // ================================================================================
    public void Setup(View rootview){
        //Setup Settings
        SetupSettings();

        //Setup Radio Group
        SetupRadioGroup(rootview);
    }


    // Setup Settings
    // ================================================================================
    // ================================================================================
    public void SetupSettings(){
        //Set Settings Object
        settings = (UserSettings)getActivity().getApplication();

        //Setup Settings Object
        settings.SetUp();
    }


    // Setup Radio Group
    // ================================================================================
    // ================================================================================
    public void SetupRadioGroup(View rootview){
        //Get Radio Group
        group = rootview.findViewById(R.id.rgGroup);

        //Set Checked Change Listener
        group.setOnCheckedChangeListener(CheckedChanged);

        //Check Radio Button
        group.check(settings.getInteger(UserSettings.CUSTOM_KEYBOARD_ID, R.id.rbQWERTY));
    }
    // endregion Setup



    // region Events
    // Checked Change Listener
    // ================================================================================
    // ================================================================================
    private RadioGroup.OnCheckedChangeListener CheckedChanged = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            //Get Checked Radio Button's Content
            String content = getCheckedRadioButtonContent(group);

            //Validate Setting Save
            if(settings.getString(UserSettings.CUSTOM_KEYBOARD, UserSettings.DEFAULT_KEYBOARD) != content){
                //Save Radio Button's ID
                settings.setInteger(UserSettings.CUSTOM_KEYBOARD_ID, group.getCheckedRadioButtonId());

                //Save Radio Button's Content
                settings.setString(UserSettings.CUSTOM_KEYBOARD, content);
            }
        }
    };
    // endregion Events



    // region Extensions
    // Get Checked Radio Button Content
    // ================================================================================
    // ================================================================================
    public String getCheckedRadioButtonContent(RadioGroup group) {
        //Get Radio Button
        RadioButton button = group.findViewById(group.getCheckedRadioButtonId());

        //Validate Radio Button
        if(button != null) {
            //Get Radio Button's Content
            return button.getText().toString();
        }

        //Return Empty String
        return UserSettings.DEFAULT_KEYBOARD;
    }
    // endregion Extensions
}