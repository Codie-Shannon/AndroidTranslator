package com.example.texttospeech;

import android.widget.Switch;
import java.util.List;

public class Switches {
    // region Internal Variables
    // Switch
    // ================================================================================
    // ================================================================================
    private Switch _switch;


    // Key
    // ================================================================================
    // ================================================================================
    private String Key;


    // Default Value
    // ================================================================================
    // ================================================================================
    private Boolean defaultValue;
    // endregion Internal Variables



    // Constructor
    // ================================================================================
    // ================================================================================
    public Switches(Switch _switch, String key, Boolean defaultvalue) {
        //Set Variables
        this._switch = _switch;
        this.Key = key;
        this.defaultValue = defaultvalue;
    }



    // region Internal Methods
    // Get Bar
    // ================================================================================
    // ================================================================================
    public Switch getSwitch() { return this._switch; }


    // Get Key
    // ================================================================================
    // ================================================================================
    public String getKey() { return this.Key; }


    // Get Default Value
    // ================================================================================
    // ================================================================================
    public Boolean getDefaultValue() { return this.defaultValue; }
    // endregion Internal Methods



    // region External Methods
    // Set Switches
    // ================================================================================
    // ================================================================================
    public static void Set(List<Switches> switches, UserSettings settings){
        //Loop Through Switches
        for (int i = 0; i < switches.size(); i++) {
            //Get Current Looped Switch
            Switches _switch = switches.get(i);

            //Set Switch's Value
            _switch.getSwitch().setChecked(settings.getBoolean(_switch.getKey(), _switch.getDefaultValue()));

            //Set Change Listener
            SetChangeListener(_switch.getSwitch(), settings, _switch.getKey(), _switch.getDefaultValue());
        }
    }


    // Set Change Listener
    // ================================================================================
    // ================================================================================
    private static void SetChangeListener(Switch _switch, UserSettings settings, String key, Boolean defaultvalue) {
        //Set Change Listener
        _switch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            //Validate Setting Save
            if(_switch.isChecked() != settings.getBoolean(key, defaultvalue)){
                //Save Setting
                settings.setBoolean(key, _switch.isChecked());
            }
        });
    }
    // endregion External Methods
}