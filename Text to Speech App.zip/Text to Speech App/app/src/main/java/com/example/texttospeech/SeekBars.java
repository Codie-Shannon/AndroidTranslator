package com.example.texttospeech;

import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import java.util.List;

public class SeekBars {
    // region Internal Variables
    // Seekbar Button
    // ================================================================================
    // ================================================================================
    private SeekBar seekBar;


    // User Settings Key
    // ================================================================================
    // ================================================================================
    private String Key;


    // Minus Button
    // ================================================================================
    // ================================================================================
    private Button btnMinus;


    // Plus Button
    // ================================================================================
    // ================================================================================
    private Button btnPlus;


    // Default Value
    // ================================================================================
    // ================================================================================
    private int defaultValue;


    // Incremental
    // ================================================================================
    // ================================================================================
    private int incremental;


    // Decremental
    // ================================================================================
    // ================================================================================
    private int decremental;
    // endregion Internal Variables



    // Constructor
    // ================================================================================
    // ================================================================================
    public SeekBars(SeekBar seekbar, String key, Button btnminus, Button btnplus, int defaultvalue, int incremental, int decremental) {
        //Set Variables
        this.seekBar = seekbar;
        this.Key = key;
        this.btnMinus = btnminus;
        this.btnPlus = btnplus;
        this.defaultValue = defaultvalue;
        this.incremental = incremental;
        this.decremental = decremental;
    }



    // region Internal Methods
    // Get Bar
    // ================================================================================
    // ================================================================================
    public SeekBar getBar() { return this.seekBar; }


    // Get Key
    // ================================================================================
    // ================================================================================
    public String getKey() { return this.Key; }


    // Get Minus Button
    // ================================================================================
    // ================================================================================
    public Button getMinusButton() { return this.btnMinus; }


    // Get Plus Button
    // ================================================================================
    // ================================================================================
    public Button getPlusButton() { return this.btnPlus; }


    // Default Value
    // ================================================================================
    // ================================================================================
    public int getDefaultValue() { return this.defaultValue; }


    // Incremental
    // ================================================================================
    // ================================================================================
    public int getIncremental() { return this.incremental; }


    // Decremental
    // ================================================================================
    // ================================================================================
    public int getDecremental() { return this.decremental; }
    // endregion Internal Methods



    // region External Methods
    // Set Seek Bars
    // ================================================================================
    // ================================================================================
    public static void Set(List<SeekBars> seekbars, UserSettings settings){
        //Loop Through Seek Bars
        for (int i = 0; i < seekbars.size(); i++) {
            //Get Current Looped Seek Bar
            SeekBars seekbar = seekbars.get(i);

            //Set Progress Bar's Value
            seekbar.getBar().setProgress(settings.getInteger(seekbar.getKey(), Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && (seekbar.getDefaultValue() < seekbar.getBar().getMin() || seekbar.getDefaultValue() > seekbar.getBar().getMax()) ? seekbar.getBar().getMin() : seekbar.getDefaultValue()));

            //Set Touch Listener
            SetTouchListener(seekbar.getBar());

            //Set Change Listener
            SetChangeListener(seekbar.getBar(), settings, seekbar.getKey(), seekbar.getDefaultValue());

            //Set Minus
            seekbar.SetMinus(seekbar.getBar(), seekbar.getMinusButton(), seekbar.getDecremental());

            //Set Plus
            seekbar.SetPlus(seekbar.getBar(), seekbar.getPlusButton(), seekbar.getIncremental());
        }
    }


    // Set Touch Listener
    // ================================================================================
    // ================================================================================
    private static void SetTouchListener(SeekBar bar) {
        //Set Touch Listener
        bar.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) { return true; }
        });
    }


    // Set Change Listener
    // ================================================================================
    // ================================================================================
    private static void SetChangeListener(SeekBar bar, UserSettings settings, String key, int defaultvalue){
        //Set Change Listener
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,boolean fromUser) {
                //Validate Setting Save
                if(bar.getProgress() != settings.getInteger(key, defaultvalue)) {
                    //Save Setting
                    settings.setInteger(key, bar.getProgress());
                }
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) { } @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
    }


    // Set Minus
    // ================================================================================
    // ================================================================================
    private void SetMinus(SeekBar bar, Button btnminus, int decremental){
        //Set Click Listener
        btnminus.setOnClickListener(view -> {
            //Validate Decrement
            if(bar.getProgress() > decremental) {
                //Decrement Bar
                bar.setProgress(bar.getProgress() - decremental);
            }
        });
    }


    // Set Plus
    // ================================================================================
    // ================================================================================
    private void SetPlus(SeekBar bar, Button btnplus, int incremental){
        //Set Click Listener
        btnplus.setOnClickListener(view -> {
            //Increment Bar
            bar.setProgress(bar.getProgress() + incremental);
        });
    }
    // endregion External Methods
}