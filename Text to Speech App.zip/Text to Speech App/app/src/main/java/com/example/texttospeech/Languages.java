package com.example.texttospeech;

import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import java.util.List;

public class Languages {
    // region Variables
    // Language
    // ================================================================================
    // ================================================================================
    private String language;


    // Male Key
    // ================================================================================
    // ================================================================================
    private String maleKey;


    // Female Key
    // ================================================================================
    // ================================================================================
    private String femaleKey;
    // endregion Variables



    // Constructor
    // ================================================================================
    // ================================================================================
    public Languages(String language, String malekey, String femalekey) {
        //Set Variables
        this.language = language;
        this.maleKey = malekey;
        this.femaleKey = femalekey;
    }



    // region Internal Methods
    // Get Language
    // ================================================================================
    // ================================================================================
    public String getLanguage() { return this.language; }


    // Get Male Key
    // ================================================================================
    // ================================================================================
    public String getMaleKey() { return this.maleKey; }


    // Get Female Key
    // ================================================================================
    // ================================================================================
    public String getFemaleKey() { return this.femaleKey; }
    // endregion Internal Methods



    // region External Methods
    // Get Language
    // ================================================================================
    // ================================================================================
    public static Voice Get(List<Languages> languages, UserSettings settings, TextToSpeech tts) {
        //Initialize Variables
        String gender = settings.getString(UserSettings.CUSTOM_GENDER, UserSettings.DEFAULT_GENDER);
        String language = settings.getString(UserSettings.CUSTOM_LANGUAGE, UserSettings.DEFAULT_LANGUAGE);

        //Loop Through Languages List
        for (Languages languageobject : languages) {
            //Check if the Current Looped Language is the Set Language
            if (languageobject.getLanguage().equals(language)) {
                //Validate Gender
                if (gender.equals(UserSettings.MALE_GENDER)) {
                    //Return Language's Male Voice
                    return GetVoice(languageobject.getMaleKey(), tts);
                } else {
                    //Return Language's Female Voice
                    return GetVoice(languageobject.getFemaleKey(), tts);
                }
            }
        }

        //Return Default Voice
        return tts.getVoice();
    }


    // Get Voice
    // ================================================================================
    // ================================================================================
    private static Voice GetVoice(String key, TextToSpeech tts){
        //Loop Through Voices List
        for (Voice voice : tts.getVoices()){
            //Validate Current Looped Voice Name
            if(voice.getName().equals(key)){
                //Return Voice
                return voice;
            }
        }

        //Return Default Voice
        return tts.getVoice();
    }
    // endregion External Methods
}