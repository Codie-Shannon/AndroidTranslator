package com.example.texttospeech;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

public class SettingsMenuFragment extends Fragment {
    // Variables
    // ================================================================================
    // ================================================================================
    List<Fragments> fragments = new ArrayList<Fragments>();


    // Useless
    // ================================================================================
    // ================================================================================
    public SettingsMenuFragment() { /* Required empty public constructor */ }


    // New Instance
    // ================================================================================
    // ================================================================================
    public static SettingsMenuFragment newInstance() { return new SettingsMenuFragment(); }


    // onCreate
    // ================================================================================
    // ================================================================================
    @Override
    public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); }


    // onCreateView
    // ================================================================================
    // ================================================================================
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_settings_menu, container, false);

        // Set Navigation
        SetNavigation(rootView);

        // Return RootView
        return rootView;
    }


    // Set Navigation
    // ================================================================================
    // ================================================================================
    public void SetNavigation(View rootview) {
        //Add Fragments to List
        fragments.add(new Fragments(Fragments.getButton(rootview, R.id.btnKeyboard), null, R.id.fragSettings, SettingsKeyboardFragment.class));
        fragments.add(new Fragments(Fragments.getButton(rootview, R.id.btnSpeech), null, R.id.fragSettings, SpeechFragment.class));
        fragments.add(new Fragments(Fragments.getButton(rootview, R.id.btnThemes), null, R.id.fragSettings, ThemesFragment.class));

        //Set Event Handlers
        Fragments.SetEventHandlers(getParentFragmentManager(), fragments);
    }
}