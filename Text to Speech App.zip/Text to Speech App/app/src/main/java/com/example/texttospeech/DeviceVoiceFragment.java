package com.example.texttospeech;

import android.os.Bundle;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class DeviceVoiceFragment extends Fragment {
    // region Variables
    // Languages List
    // ================================================================================
    // ================================================================================
    List<CheckBoxes> languagesList = new ArrayList<CheckBoxes>();


    // Genders List
    // ================================================================================
    // ================================================================================
    List<CheckBoxes> gendersList = new ArrayList<CheckBoxes>();


    // Settings
    // ================================================================================
    // ================================================================================
    private UserSettings settings;
    // endregion Variables



    // Useless
    // ================================================================================
    // ================================================================================
    public DeviceVoiceFragment() { /* Required empty public constructor */ }



    // New Instance
    // ================================================================================
    // ================================================================================
    public static DeviceVoiceFragment newInstance() { return new DeviceVoiceFragment(); }



    // onCreate
    // ================================================================================
    // ================================================================================
    @Override
    public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); }



    // onCreateView
    // ================================================================================
    // ================================================================================
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_device_voice, container, false);

        // Setup
        Setup(rootView);

        // Return RootView
        return rootView;
    }



    // region Setup
    // Setup
    // ================================================================================
    // ================================================================================
    public void Setup(View rootview){
        //Setup Settings
        SetupSettings();

        //Set Languages
        SetupLanguages(rootview);

        //Set Genders
        SetupGenders(rootview);
    }


    // Setup Settings
    // ================================================================================
    // ================================================================================
    public void SetupSettings(){
        //Set Settings Object
        settings = (UserSettings)getActivity().getApplication();

        //Setup Settings Object
        settings.SetUp();
    }


    // Setup Languages
    // ================================================================================
    // ================================================================================
    public void SetupLanguages(View rootview){
        //Add Languages to List
        languagesList.add(new CheckBoxes(UserSettings.AUSTRALIAN_LANGUAGE, UserSettings.CUSTOM_LANGUAGE, rootview.findViewById(R.id.btnAustralian), rootview.findViewById(R.id.cbAustralian), UserSettings.DEFAULT_LANGUAGE));
        languagesList.add(new CheckBoxes(UserSettings.AMERICAN_LANGUAGE, UserSettings.CUSTOM_LANGUAGE, rootview.findViewById(R.id.btnAmerican), rootview.findViewById(R.id.cbAmerican), UserSettings.DEFAULT_LANGUAGE));

        //Setup CheckBoxes
        CheckBoxes.Setup("languages", languagesList, settings, UserSettings.CUSTOM_LANGUAGE, UserSettings.DEFAULT_LANGUAGE);
    }


    // Setup Genders
    // ================================================================================
    // ================================================================================
    public void SetupGenders(View rootview){
        //Add Genders to List
        gendersList.add(new CheckBoxes(UserSettings.MALE_GENDER, UserSettings.CUSTOM_GENDER, rootview.findViewById(R.id.btnMale), rootview.findViewById(R.id.cbMale), UserSettings.DEFAULT_GENDER));
        gendersList.add(new CheckBoxes(UserSettings.FEMALE_GENDER, UserSettings.CUSTOM_GENDER, rootview.findViewById(R.id.btnFemale), rootview.findViewById(R.id.cbFemale), UserSettings.DEFAULT_GENDER));

        //Setup CheckBoxes
        CheckBoxes.Setup("genders", gendersList, settings, UserSettings.CUSTOM_GENDER, UserSettings.DEFAULT_GENDER);
    }
    // endregion Setup
}