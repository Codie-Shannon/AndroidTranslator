package com.example.texttospeech;

import android.app.Activity;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import com.google.android.material.button.MaterialButton;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class KeyboardFragment extends Fragment {
    // region Variables
    // Character
    // ================================================================================
    // ================================================================================
    private static Character _character = Character.UPPERCASE;



    // Buttons
    // ================================================================================
    // ================================================================================
    Button btnSwitch;
    private static MaterialButton btnChange;



    // Image Buttons
    // ================================================================================
    // ================================================================================
    ImageButton btnEnter, btnErase, btnWait;



    // Standard Buttons List
    // ================================================================================
    // ================================================================================
    List<Button> standardbuttons = new ArrayList<Button>();



    // Dynamic Buttons List
    // ================================================================================
    // ================================================================================
    private static List<KeyboardButton> dynamicbuttons = new ArrayList<KeyboardButton>();



    // Wait List
    // ================================================================================
    // ================================================================================
    List<String> waitList = Arrays.asList(
            "Please wait a second while I type a sentence with my text to speech application.",
            "Hold on while I use my text to speech application to type a sentence.",
            "I am almost there.",
            "Please bare with me while I use my text to speech application to speak.",
            "Please wait a minute."
    );



    // Settings
    // ================================================================================
    // ================================================================================
    private static UserSettings settings;
    // endregion Variables




    // Useless
    // ================================================================================
    // ================================================================================
    public KeyboardFragment() { /* Required empty public constructor */ }




    // New Instance
    // ================================================================================
    // ================================================================================
    public static KeyboardFragment newInstance() { return new KeyboardFragment(); }




    // onCreate
    // ================================================================================
    // ================================================================================
    @Override
    public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); }




    // onCreateView
    // ================================================================================
    // ================================================================================
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_keyboard, container, false);

        // Setup
        Setup(rootView);

        // Return RootView
        return rootView;
    }




    // region Setup
    // Setup
    // ================================================================================
    // ================================================================================
    public void Setup(View rootview) {
        //Setup Settings
        SetupSettings();

        //Get Dynamic Buttons
        GetDynamicButtons(rootview);

        //Get Standard Buttons
        GetStandardButtons(rootview);

        //Get Special Buttons
        GetSpecialButtons(rootview);

        //Set Change
        SetChange();

        //Set Event Handlers
        SetEventHandlers();
    }



    // Setup Settings
    // ================================================================================
    // ================================================================================
    public void SetupSettings() {
        //Set Settings Object
        settings = (UserSettings) getActivity().getApplication();

        //Setup Settings Object
        settings.SetUp();
    }
    // endregion Setup




    // region Event Handler Methods
    // Set Event Handlers
    // ================================================================================
    // ================================================================================
    public void SetEventHandlers() {
        //Set Dynamic Button Event Handlers
        SetDynamicEventHandlers();

        //Set Standard Button Event Handlers
        SetStandardEventHandlers();

        //Set Special Button Event Handlers
        SetSpecialEventHandlers();
    }



    // Set Dynamic Button Event Handlers
    // ================================================================================
    // ================================================================================
    public void SetDynamicEventHandlers() {
        //Loop Through Dynamic Buttons List
        for (int i = 0; i < dynamicbuttons.size(); i++) {
            //Get Current Looped Button
            Button button = dynamicbuttons.get(i).getButton();

            //Set Click Listener
            button.setOnClickListener(view -> {
                //Add Character to Input Field
                Type(button);

                //Validate Character
                if (_character == Character.UPPERCASE) {
                    //Change Character
                    _character = Character.LOWERCASE;

                    //Set Change
                    SetChange();
                }
            });
        }
    }



    // Set Standard Button Event Handlers
    // ================================================================================
    // ================================================================================
    public void SetStandardEventHandlers() {
        //Loop Through Standard Buttons List
        for (int i = 0; i < standardbuttons.size(); i++) {
            //Get Current Looped Button
            Button button = standardbuttons.get(i);

            //Set Click Listener
            button.setOnClickListener(view -> {
                //Add Character to Input Field
                Type(button);
            });
        }
    }



    // Set Special Button Event Handlers
    // ================================================================================
    // ================================================================================
    public void SetSpecialEventHandlers() {
        //Set Change Event Handler (Change Character Set)
        btnChange.setOnClickListener(view -> { Change(); });

        //Set Switch Event Handler (Switch Character Set)
        btnSwitch.setOnClickListener(view -> { Switch(); });

        //Set Enter Event Handler (Add New Line to Input Field)
        btnEnter.setOnClickListener(view -> { TextFragment.Enter(); });

        //Set Erase Event Handler (Erase Last Character in Input Field)
        btnErase.setOnClickListener(view -> { Erase(); });

        //Set Wait Event Handler
        btnWait.setOnClickListener(view -> { Wait(); });
    }
    // endregion Event Handler Methods




    // region Internal Methods
    // Get Dynamic Buttons
    // ================================================================================
    public void GetDynamicButtons(View rootview) {
        //Add Dynamic Buttons to List
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn1), R.string.UCQ, R.string.LCQ, R.string.UCA, R.string.LCA, R.string.NP1, R.string.NP1));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn2), R.string.UCW, R.string.LCW, R.string.UCB, R.string.LCB, R.string.NP2, R.string.NP2));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn3), R.string.UCE, R.string.LCE, R.string.UCC, R.string.LCC, R.string.NP3, R.string.NP3));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn4), R.string.UCR, R.string.LCR, R.string.UCD, R.string.LCD, R.string.NP4, R.string.NP4));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn5), R.string.UCT, R.string.LCT, R.string.UCE, R.string.LCE, R.string.NP5, R.string.NP5));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn6), R.string.UCY, R.string.LCY, R.string.UCF, R.string.LCF, R.string.NP6, R.string.NP6));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn7), R.string.UCU, R.string.LCU, R.string.UCG, R.string.LCG, R.string.NP7, R.string.NP7));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn8), R.string.UCI, R.string.LCI, R.string.UCH, R.string.LCH, R.string.NP8, R.string.NP8));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn9), R.string.UCO, R.string.LCO, R.string.UCI, R.string.LCI, R.string.NP9, R.string.NP9));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn10), R.string.UCP, R.string.LCP, R.string.UCJ, R.string.LCJ, R.string.NP0, R.string.NP0));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn11), R.string.UCA, R.string.LCA, R.string.UCK, R.string.LCK, R.string.NPAT, R.string.SCCENT));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn12), R.string.UCS, R.string.LCS, R.string.UCL, R.string.LCL, R.string.NPHASH, R.string.SCDOLLAR));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn13), R.string.UCD, R.string.LCD, R.string.UCM, R.string.LCM, R.string.NPPOUND, R.string.SCYUAN));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn14), R.string.UCF, R.string.LCF, R.string.UCN, R.string.LCN, R.string.NPAND, R.string.SCUNDERSCORE));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn15), R.string.UCG, R.string.LCG, R.string.UCO, R.string.LCO, R.string.NPPERCENT, R.string.SCCARET));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn16), R.string.UCH, R.string.LCH, R.string.UCP, R.string.LCP, R.string.NPLEFTPARENTHESIS, R.string.SCOPENBRACKET));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn17), R.string.UCJ, R.string.LCJ, R.string.UCQ, R.string.LCQ, R.string.NPRIGHTPARENTHESIS, R.string.SCCLOSEDBRACKET));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn18), R.string.UCK, R.string.LCK, R.string.UCR, R.string.LCR, R.string.NPSINGLEQUOTE, R.string.SCOPENBRACE));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn19), R.string.UCL, R.string.LCL, R.string.UCS, R.string.LCS, R.string.NPQUOTE, R.string.SCCLOSEDBRACE));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn20), R.string.UCZ, R.string.LCZ, R.string.UCT, R.string.LCT, R.string.NPMINUS, R.string.SCASTERISK));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn21), R.string.UCX, R.string.LCX, R.string.UCU, R.string.LCU, R.string.NPPLUS, R.string.SCPIPE));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn22), R.string.UCC, R.string.LCC, R.string.UCV, R.string.LCV, R.string.NPEQUAL, R.string.SCTILDE));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn23), R.string.UCV, R.string.LCV, R.string.UCW, R.string.LCW, R.string.NPFORWARDSLASH, R.string.SCCOLON));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn24), R.string.UCB, R.string.LCB, R.string.UCX, R.string.LCX, R.string.NPSEMICOLON, R.string.SCBACKSLASH));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn25), R.string.UCN, R.string.LCN, R.string.UCY, R.string.LCY, R.string.NPQUESTIONMARK, R.string.SCLESSTHAN));
        dynamicbuttons.add(new KeyboardButton(rootview.findViewById(R.id.btn26), R.string.UCM, R.string.LCM, R.string.UCZ, R.string.LCZ, R.string.NPEXCLAMATIONMARK, R.string.SCGREATERTHAN));
    }


    // Get Standard Buttons
    // ================================================================================
    public void GetStandardButtons(View rootview) {
        //Add Standard Buttons to List
        standardbuttons.add(rootview.findViewById(R.id.btnFullStop));
        standardbuttons.add(rootview.findViewById(R.id.btnComma));
        standardbuttons.add(rootview.findViewById(R.id.btnSpace));
    }


    // Get Special Buttons
    // ================================================================================
    public void GetSpecialButtons(View rootview){
        //Get Special Buttons
        btnChange = rootview.findViewById(R.id.btnChange);
        btnEnter = rootview.findViewById(R.id.btnEnter);
        btnErase = rootview.findViewById(R.id.btnErase);
        btnSwitch = rootview.findViewById(R.id.btnSwitch);
        btnWait = rootview.findViewById(R.id.btnWait);
    }



    // Change Character Set
    // ================================================================================
    // ================================================================================
    // Change
    // ================================================================================
    public void Change() {
        //Validate Character
        if (_character == Character.NUMBER_PAD || _character == Character.SPECIAL_CHARACTER) {
            //Change Character
            _character = Character.Switch(_character);

            //Set Switch
            SetSwitch();
        } else {
            //Change Character
            _character = Character.Change(_character);

            //Set Change
            SetChange();
        }
    }


    // Set Change
    // ================================================================================
    public void SetChange() {
        //Loop Through Dynamic Buttons List
        for (int i = 0; i < dynamicbuttons.size(); i++) {
            //Get Current Looped Dynamic Button
            KeyboardButton button = dynamicbuttons.get(i);

            //Validate Character
            if (_character == Character.UPPERCASE || _character == Character.PERMANENT_UPPERCASE) {
                //Set Case
                button.getButton().setText(settings.getString(UserSettings.CUSTOM_KEYBOARD, UserSettings.DEFAULT_KEYBOARD).contains(UserSettings.QWERTY_KEYBOARD) ? getString(button.getUppercaseQWERTY()) : getString(button.getUppercaseABC()));

                //Set Icon
                btnChange.setIcon(getResources().getDrawable(_character == Character.UPPERCASE ? R.drawable.uppercase : R.drawable.permanent_uppercase));
            } else {
                //Set Case
                button.getButton().setText(settings.getString(UserSettings.CUSTOM_KEYBOARD, UserSettings.DEFAULT_KEYBOARD).contains(UserSettings.QWERTY_KEYBOARD) ? getString(button.getLowercaseQWERTY()) : getString(button.getLowercaseABC()));

                //Set Icon
                btnChange.setIcon(getResources().getDrawable(R.drawable.lowercase));
            }
        }
    }



    // Switch Character Set
    // ================================================================================
    // ================================================================================
    // Switch
    // ================================================================================
    public void Switch(){
        //Validate Switch
        if(_character != Character.NUMBER_PAD && _character != Character.SPECIAL_CHARACTER){
            //Change Character
            _character = Character.Switch(_character);

            //Set Switch Text
            btnSwitch.setText(getString(R.string.SwitchABC));

            //Clear Change Button Icon
            btnChange.setIcon(null);

            //Set Change Button Text
            btnChange.setText(R.string.ChangeNumPad);

            //Set Switch
            SetSwitch();
        }
        else{
            //Set Character to Uppercase
            _character = Character.UPPERCASE;

            //Set Switch Text
            btnSwitch.setText(getString(R.string.Switch123));

            //Clear Change Button Text
            btnChange.setText("");

            //Set Change Button Icon
            btnChange.setIcon(getResources().getDrawable(R.drawable.uppercase));

            //Set Change
            SetChange();
        }
    }


    // Set Switch
    // ================================================================================
    public void SetSwitch(){
        //Loop Through Dynamic Buttons List
        for (int i = 0; i < dynamicbuttons.size(); i++) {
            //Get Current Looped Dynamic Button
            KeyboardButton button = dynamicbuttons.get(i);

            //Validate Switch
            if(_character == Character.NUMBER_PAD){
                //Set Switch
                button.getButton().setText(getString(button.getNumberPad()));

                //Set Change Button Text
                btnChange.setText(R.string.ChangeNumPad);
            }
            else {
                //Set Switch
                button.getButton().setText(getString(button.getSpecialCharacter()));

                //Set Change Button Text
                btnChange.setText(R.string.ChangeSpecChars);
            }
        }
    }



    // Erase
    // ================================================================================
    // ================================================================================
    public void Erase() {
        //Erase Text
        Boolean isEmpty = TextFragment.Erase();

        //Check if the Input Field is Empty
        if(isEmpty) {
            //Set Uppercase Characters
            SetUppercase(getActivity());
        }
    }



    // Type Character
    // ================================================================================
    // ================================================================================
    public void Type(Button button) { TextFragment.Type(button.getText().toString()); }



    // Wait
    // ================================================================================
    // ================================================================================
    public void Wait() {
        //Generate Random Number
        int random = ThreadLocalRandom.current().nextInt(0, waitList.size());

        //Speak Random Wait Phrase
        TextFragment.Speak(waitList.get(random), false);
    }
    // endregion Internal Methods




    // region External Methods
    // Set Uppercase
    // ================================================================================
    // ================================================================================
    public static void SetUppercase(Activity activity){
        //Set Uppercase
        _character = Character.UPPERCASE;

        //Loop Through Dynamic Buttons List
        for (int i = 0; i < dynamicbuttons.size(); i++) {
            //Get Current Looped Dynamic Button
            KeyboardButton button = dynamicbuttons.get(i);

            //Set Case
            button.getButton().setText(settings.getString(UserSettings.CUSTOM_KEYBOARD, UserSettings.DEFAULT_KEYBOARD).contains(UserSettings.QWERTY_KEYBOARD) ? activity.getString(button.getUppercaseQWERTY()) : activity.getString(button.getUppercaseABC()));

            //Set Icon
            btnChange.setIcon(activity.getResources().getDrawable(R.drawable.uppercase));
        }
    }
    // endregion External Methods
}