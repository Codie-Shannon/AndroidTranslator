package com.example.texttospeech;

public enum Character {
    // Enumeration Types
    // ================================================================================
    // ================================================================================
    UPPERCASE, PERMANENT_UPPERCASE, LOWERCASE, NUMBER_PAD, SPECIAL_CHARACTER;



    // region External Methods
    // Change Character
    // ================================================================================
    // ================================================================================
    public static Character Change(Character _character){
        //Validate Change
        if(_character == Character.UPPERCASE || _character == Character.NUMBER_PAD || _character == Character.SPECIAL_CHARACTER){
            //Return PERMANENT UPPERCASE Value
            return Character.PERMANENT_UPPERCASE;
        }
        else if(_character == Character.PERMANENT_UPPERCASE){
            //Return LOWERCASE Value
            return Character.LOWERCASE;
        }
        else{
            //Return UPPERCASE Value
            return Character.UPPERCASE;
        }
    }


    // Change Switch
    // ================================================================================
    // ================================================================================
    public static Character Switch(Character _character){
        //Validate Change
        if(_character == Character.UPPERCASE || _character == Character.PERMANENT_UPPERCASE || _character == Character.LOWERCASE || _character == Character.SPECIAL_CHARACTER){
            //Return NUMBER PAD Value
            return Character.NUMBER_PAD;
        }
        else {
            //Return SPECIAL CHARACTER Value
            return Character.SPECIAL_CHARACTER;
        }
    }
    // endregion External Methods
}