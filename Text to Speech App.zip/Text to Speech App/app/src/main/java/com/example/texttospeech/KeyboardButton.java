package com.example.texttospeech;

import android.widget.Button;

public class KeyboardButton {
    // region Internal Variables
    // Button
    // ================================================================================
    // ================================================================================
    private Button button;


    // Uppercase QWERTY
    // ================================================================================
    // ================================================================================
    private int UppercaseQWERTY;


    // Lowercase QWERTY
    // ================================================================================
    // ================================================================================
    private int LowercaseQWERTY;


    // Uppercase ABC
    // ================================================================================
    // ================================================================================
    private int UppercaseABC;


    // Lowercase ABC
    // ================================================================================
    // ================================================================================
    private int LowercaseABC;


    // Number Pad
    // ================================================================================
    // ================================================================================
    private int NumberPad;


    // Special Character
    // ================================================================================
    // ================================================================================
    private int SpecialCharacter;
    // endregion Internal Variables



    // Constructor
    // ================================================================================
    // ================================================================================
    public KeyboardButton(Button button, int uppercaseqwerty, int lowercaseqwerty, int uppercaseabc, int lowercaseabc, int numberpad, int specialcharacter) {
        //Set Variables
        this.button = button;
        this.UppercaseQWERTY = uppercaseqwerty;
        this.LowercaseQWERTY = lowercaseqwerty;
        this.UppercaseABC = uppercaseabc;
        this.LowercaseABC = lowercaseabc;
        this.NumberPad = numberpad;
        this.SpecialCharacter = specialcharacter;
    }



    // region Internal Methods
    // Get Button
    // ================================================================================
    // ================================================================================
    public Button getButton() { return this.button; }


    // Get Uppercase QWERTY
    // ================================================================================
    // ================================================================================
    public int getUppercaseQWERTY() { return this.UppercaseQWERTY; }


    // Get Lowercase QWERTY
    // ================================================================================
    // ================================================================================
    public int getLowercaseQWERTY() { return this.LowercaseQWERTY; }


    // Get Uppercase ABC
    // ================================================================================
    // ================================================================================
    public int getUppercaseABC() { return this.UppercaseABC; }


    // Get Lowercase ABC
    // ================================================================================
    // ================================================================================
    public int getLowercaseABC() { return this.LowercaseABC; }


    // Get Number Pad
    // ================================================================================
    // ================================================================================
    public int getNumberPad() { return this.NumberPad; }


    // Get Special Character
    // ================================================================================
    // ================================================================================
    public int getSpecialCharacter() { return this.SpecialCharacter; }
    // endregion Internal Methods
}