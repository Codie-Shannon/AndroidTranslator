package com.example.texttospeech;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

public class SpeechFragment extends Fragment {
    // region Variables
    // Fragments List
    // ================================================================================
    // ================================================================================
    List<Fragments> fragmentsList = new ArrayList<Fragments>();


    // Seek Bars List
    // ================================================================================
    // ================================================================================
    List<SeekBars> seekbarsList = new ArrayList<SeekBars>();


    // Switches List
    // ================================================================================
    // ================================================================================
    List<Switches> switchesList = new ArrayList<Switches>();


    // Settings
    // ================================================================================
    // ================================================================================
    private UserSettings settings;
    // endregion Variables



    // Useless
    // ================================================================================
    // ================================================================================
    public SpeechFragment() { /* Required empty public constructor */ }



    // New Instance
    // ================================================================================
    // ================================================================================
    public static SpeechFragment newInstance() { return new SpeechFragment(); }



    // onCreate
    // ================================================================================
    // ================================================================================
    @Override
    public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); }



    // onCreateView
    // ================================================================================
    // ================================================================================
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_speech, container, false);

        // Setup
        Setup(rootView);

        // Return RootView
        return rootView;
    }



    // region Setup
    // Setup
    // ================================================================================
    // ================================================================================
    public void Setup(View rootview){
        //Setup Settings
        SetupSettings();

        //Setup Navigation
        SetupNavigation(rootview);

        //Setup Switches
        SetupSwitches(rootview);

        //Setup Seek Bars
        SetupSeekBars(rootview);
    }


    // Setup Settings
    // ================================================================================
    // ================================================================================
    public void SetupSettings(){
        //Set Settings Object
        settings = (UserSettings)getActivity().getApplication();

        //Setup Settings Object
        settings.SetUp();
    }


    // Setup Navigation
    // ================================================================================
    // ================================================================================
    public void SetupNavigation(View rootview) {
        //Add Fragments to List
        fragmentsList.add(new Fragments(Fragments.getButton(rootview, R.id.btnAdvanced), null, R.id.fragSettings, MessageWindowFragment.class));
        fragmentsList.add(new Fragments(Fragments.getButton(rootview, R.id.btnDeviceVoice), null, R.id.fragSettings, DeviceVoiceFragment.class));

        //Set Event Handlers
        Fragments.SetEventHandlers(getParentFragmentManager(), fragmentsList);
    }


    // Setup Seek Bars
    // ================================================================================
    // ================================================================================
    public void SetupSeekBars(View rootview) {
        //Add Seek Bars to List
        seekbarsList.add(new SeekBars(rootview.findViewById(R.id.skbarRate), UserSettings.CUSTOM_SPEAK_RATE, rootview.findViewById(R.id.btnRateMinus), rootview.findViewById(R.id.btnRatePlus), 10, 10, 10));
        seekbarsList.add(new SeekBars(rootview.findViewById(R.id.skbarPitch), UserSettings.CUSTOM_SPEAK_PITCH, rootview.findViewById(R.id.btnPitchMinus), rootview.findViewById(R.id.btnPitchPlus), 10, 10, 10));

        //Set Seek Bars
        SeekBars.Set(seekbarsList, settings);
    }


    // Setup Switches
    // ================================================================================
    // ================================================================================
    public void SetupSwitches(View rootview){
        //Add Switches to List
        switchesList.add(new Switches(rootview.findViewById(R.id.swiClearAfterSpeak), UserSettings.CUSTOM_CLEAR_AFTER_SPEAK, UserSettings.DEFAULT_CLEAR_AFTER_SPEAK));
        switchesList.add(new Switches(rootview.findViewById(R.id.swiSpeakPhrasesOnTap), UserSettings.CUSTOM_SPEAK_PHRASES_ON_TAP, UserSettings.DEFAULT_CLEAR_AFTER_SPEAK));

        //Set Switches
        Switches.Set(switchesList, settings);
    }
    // endregion Setup
}