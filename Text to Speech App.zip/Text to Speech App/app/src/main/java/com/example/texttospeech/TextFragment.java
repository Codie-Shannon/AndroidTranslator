package com.example.texttospeech;

import android.app.Activity;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import java.text.BreakIterator;
import java.util.Arrays;
import java.util.List;

import kotlin.text.Regex;

public class TextFragment extends Fragment {
    // region Variables
    // Input Field
    // ================================================================================
    // ================================================================================
    public static EditText edttxtInput;


    // Message Window Function Button
    // ================================================================================
    // ================================================================================
    private Button btnMsgWind;


    // Text To Speech
    // ================================================================================
    // ================================================================================
    private static TextToSpeech TTS;


    // Settings
    // ================================================================================
    // ================================================================================
    private static UserSettings settings;


    // Languages
    // ================================================================================
    // ================================================================================
    private List<Languages> languagesList = Arrays.asList(
            new Languages("australian", "en-au-x-aub-local", "en-AU-language"),
            new Languages("american", "en-us-x-iom-local", "en-US-language")
    );
    // endregion Variables



    // Useless
    // ================================================================================
    // ================================================================================
    public TextFragment() { /* Required empty public constructor */ }



    // New Instance
    // ================================================================================
    // ================================================================================
    public static TextFragment newInstance() { return new TextFragment(); }



    // onCreate
    // ================================================================================
    // ================================================================================
    @Override
    public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); }



    // onCreateView
    // ================================================================================
    // ================================================================================
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_text, container, false);

        // Setup
        Setup(rootView);

        // Hide Soft Keyboard On Focus
        HideSoftKeyboardOnFocus();

        // Return RootView
        return rootView;
    }



    // region Setup
    // Setup
    // ================================================================================
    // ================================================================================
    public void Setup(View rootview){
        //Setup Settings
        SetupSettings();

        //Setup Input Field
        SetupInputField(rootview);

        //Setup Text To Speech
        SetupTextToSpeech();

        //Setup Message Window Function
        SetupMessageWindowFunction(rootview);
    }


    // Setup Settings
    // ================================================================================
    // ================================================================================
    public void SetupSettings(){
        // Set Settings Object
        settings = (UserSettings)getActivity().getApplication();

        // Setup Settings Object
        settings.SetUp();
    }


    // Setup Input Field
    // ================================================================================
    // ================================================================================
    public void SetupInputField(View rootview){
        // Set Edit Text Input
        edttxtInput = rootview.findViewById(R.id.edttxtInput);

        // Set Input Field's Click Listener
        edttxtInput.setOnClickListener(ClickListener);
    }


    // Setup Text To Speech
    // ================================================================================
    // ================================================================================
    public void SetupTextToSpeech() {
        //Create Text To Speech Object
        TTS = new TextToSpeech(this.getContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                //Validate Text to Speech Status
                if (status == TextToSpeech.SUCCESS) {
                    //Get Voice
                    Voice voice = Languages.Get(languagesList, settings, TTS);

                    //Set Voice
                    int result = TTS.setVoice(voice);

                    //Check if the Text to Speech Object's Language is Set
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        //Log Error Message
                        Log.e("TTS", "Language not supported");
                    } else {
                        //Log Error Message
                        Log.e("TTS", "Initialization failed");
                    }
                }
            }
        });

        //Set Text To Speech Object's Utterance Progress Listener
        TTS.setOnUtteranceProgressListener(SetUtteranceProgressListener);
    }


    // Setup Message Window Function
    // ================================================================================
    // ================================================================================
    public void SetupMessageWindowFunction(View rootview){
        //Get Message Window Function Button
        btnMsgWind = rootview.findViewById(R.id.btnMsgWind);

        //Get Message Window Mode
        Boolean isCustom = settings.getBoolean(UserSettings.CUSTOM_MESSAGE_WINDOW, UserSettings.DEFAULT_MESSAGE_WINDOW);

        //Set Message Window Function Button's Visibility
        btnMsgWind.setVisibility(isCustom ? View.VISIBLE : View.GONE);

        //Validate Message Window Mode
        if(isCustom) {
            //Set Click Listener
            btnMsgWind.setOnClickListener(MessageWindowClickListener);
        }
    }
    // endregion Setup



    // region Events
    // Click Listener
    // ================================================================================
    // ================================================================================
    private View.OnClickListener ClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            //Validate Speak
            if (settings.getBoolean(UserSettings.CUSTOM_SPEAK_PHRASES_ON_TAP, UserSettings.DEFAULT_SPEAK_PHRASES_ON_TAP)) {
                //Declare and Initialize Variables
                int start, end, cursor = edttxtInput.getSelectionStart();

                //Initialize BreakIterator
                BreakIterator iterator = BreakIterator.getWordInstance();

                //Set Iterator Content
                iterator.setText(Get());

                //Validate Cursor Position
                if(cursor != Get().length()) {
                    //Locate the Word's Boundaries
                    if (iterator.isBoundary(cursor)) {
                        //Set Start to Cursor Position
                        start = cursor;
                    } else {
                        //Set start Variable to Index of Separator Before the Cursor
                        start = iterator.preceding(cursor);
                    }

                    //Set end Variable to Index of Separator After the Cursor
                    end = iterator.following(cursor);

                    //Get Word from Input Field Text
                    CharSequence word = Get().subSequence(start, end);

                    //Speak Word
                    Speak(word.toString(), true);
                }
            }
        }
    };


    // Utterance Progress Listener
    // ================================================================================
    // ================================================================================
    private final UtteranceProgressListener SetUtteranceProgressListener = new UtteranceProgressListener() {
        @Override
        public void onDone(String utteranceId) {
            //Validate Clear After Speak
            if(settings.getBoolean(UserSettings.CUSTOM_CLEAR_AFTER_SPEAK, UserSettings.DEFAULT_CLEAR_AFTER_SPEAK)) {
                //Clear Input Field
                TextFragment.DeleteAll(getActivity());
            }
        }

        @Override public void onStart(String utteranceId) { } @Override public void onError(String utteranceId) { }
    };


    // Message Window Click Listener
    // ================================================================================
    // ================================================================================
    private View.OnClickListener MessageWindowClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            //Get Message Window Function
            String msgWinFunction = settings.getString(UserSettings.CUSTOM_MESSAGE_WINDOW_FUNCTION, UserSettings.DEFAULT_MESSAGE_WINDOW_FUNCTION);

            //Validate Message Window Function
            if (msgWinFunction.equals(UserSettings.SPEAK_ALL_MESSAGE_WINDOW_FUNCTION)) {
                //Speak All Text within Input Field
                Speak(Get(), false);
            }
            else {
                //Speak Last Sentence within Input Field
                String[] sentences = Get().split("!|\\?|\\.|;");

                //Set Sentence Variable
                String sentence = "No Text Found";

                //Loop Through Sentences Array
                for (int i = sentences.length -1; i >= 0; i--) {
                    //Remove All Special Characters From Current Looped Sentence
                    String value = sentences[i].replaceAll("[^a-zA-Z0-9]", "");

                    //Validate String
                    if(!value.isEmpty()){
                        //Set Sentence to Current Looped Sentence
                        sentence = sentences[i];

                        //Break For Loop
                        break;
                    }
                }

                //Speak Sentence
                Speak(sentence, false);
            }
        }
    };
    // endregion Events



    // region Internal Methods
    // Hide Soft Keyboard On Focus
    // ================================================================================
    // ================================================================================
    public void HideSoftKeyboardOnFocus() { edttxtInput.setShowSoftInputOnFocus(false); }
    // endregion Internal Methods



    // region External Methods
    // Speak
    // ================================================================================
    // ================================================================================
    public static void Speak(String value, Boolean isWord){
        //Set Pitch
        TTS.setPitch(settings.getInteger(UserSettings.CUSTOM_SPEAK_PITCH, 50) / 50f);

        //Set Rate
        TTS.setSpeechRate(settings.getInteger(UserSettings.CUSTOM_SPEAK_RATE, 50) / 50f);

        //Speak Input Field Text
        TTS.speak(value, TextToSpeech.QUEUE_FLUSH, null, isWord == false ? "5210" : null);
    }


    // Stop Speaking
    // ================================================================================
    // ================================================================================
    public static void StopSpeaking(){
        //Stop Text To Speech
        TTS.stop();
    }


    // Enter
    // ================================================================================
    // ================================================================================
    public static void Enter(){
        //Remove Any Selected Text
        Replace("");

        //Add New Line to Input Field
        NewLine();
    }


    // Erase
    // ================================================================================
    // ================================================================================
    public static Boolean Erase(){
        //Get Character Position
        int start = TextFragment.GetSelectionStart();
        int end = TextFragment.GetSelectionEnd();

        //Validate Input Length
        if(TextFragment.Get().length() > 0 && start != 0) {
            //Validate Removal Type
            if(start != end){
                //Remove Highlighted Text (Text Highlighted)
                TextFragment.edttxtInput.getText().delete(start, end);
            }
            else{
                //Remove Character Before Cursor (No Text Highlighted)
                TextFragment.edttxtInput.getText().delete(start -1, start);
            }

            //Check if the Input Field is Empty
            if(TextFragment.Get().length() == 0){
                //Return True
                return true;
            }
        }

        //Return False
        return false;
    }


    // Type Character
    // ================================================================================
    // ================================================================================
    public static void Type(String value) { Replace(value); }


    // Get Input
    // ================================================================================
    // ================================================================================
    public static String Get(){ return edttxtInput.getText().toString(); }


    // Delete All
    // ================================================================================
    // ================================================================================
    public static void DeleteAll(Activity activity) {
        //Clear Input Field
        edttxtInput.setText("");

        //Set Uppercase Characters
        KeyboardFragment.SetUppercase(activity);
    }
    // endregion External Methods



    // region External Extension Methods
    // Replace Selection
    // ================================================================================
    // ================================================================================
    private static void Replace(String value) {
        //Get Cursor Position or Selected Text Position
        int start = GetSelectionStart();
        int end = GetSelectionEnd();

        //Add Character to Input Field
        edttxtInput.getText().replace(Math.min(start, end), Math.max(start, end), value, 0, value.length());
    }


    // New Line
    // ================================================================================
    // ================================================================================
    private static void NewLine() { edttxtInput.getText().insert(TextFragment.edttxtInput.getSelectionStart(), "\n"); }


    // Get Selection Start
    // ================================================================================
    // ================================================================================
    private static int GetSelectionStart(){ return Math.max(edttxtInput.getSelectionStart(), 0); }


    // Get Selection End
    // ================================================================================
    // ================================================================================
    private static int GetSelectionEnd(){ return Math.max(edttxtInput.getSelectionEnd(), 0); }
    // endregion External Extension Methods
}