package com.example.texttospeech;

import android.os.Bundle;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;

public class MessageWindowFragment extends Fragment {
    // region Variables
    // Switch
    // ================================================================================
    // ================================================================================
    private Switch swiFunction;


    // Radio Group
    // ================================================================================
    // ================================================================================
    private RadioGroup rgFunctions;


    // Radio Buttons
    // ================================================================================
    // ================================================================================
    private RadioButton rbSpeakAll, rbSpeakLastSentence;


    // Settings
    // ================================================================================
    // ================================================================================
    private static UserSettings settings;
    // endregion Variables



    // Useless
    // ================================================================================
    // ================================================================================
    public MessageWindowFragment() { /* Required empty public constructor */ }



    // New Instance
    // ================================================================================
    // ================================================================================
    public static MessageWindowFragment newInstance() { return new MessageWindowFragment(); }



    // onCreate
    // ================================================================================
    // ================================================================================
    @Override
    public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); }



    // onCreateView
    // ================================================================================
    // ================================================================================
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_message_window, container, false);

        // Setup
        Setup(rootView);

        // Return RootView
        return rootView;
    }



    // region Setup
    // Setup
    // ================================================================================
    // ================================================================================
    public void Setup(View rootview){
        //Setup Settings
        SetupSettings();

        //Setup Switch
        SetupSwitch(rootview);

        //Setup Radio
        SetupRadio(rootview);
    }


    // Setup Settings
    // ================================================================================
    // ================================================================================
    public void SetupSettings(){
        // Set Settings Object
        settings = (UserSettings)getActivity().getApplication();

        // Setup Settings Object
        settings.SetUp();
    }


    // Setup Switch
    // ================================================================================
    // ================================================================================
    public void SetupSwitch(View rootview){
        //Get Switch
        swiFunction = rootview.findViewById(R.id.swiFunction);

        //Set Switch
        swiFunction.setChecked(settings.getBoolean(UserSettings.CUSTOM_MESSAGE_WINDOW, UserSettings.DEFAULT_MESSAGE_WINDOW));

        //Set Checked Change Listener
        swiFunction.setOnCheckedChangeListener(CheckedChangeListener);
    }


    // Setup Radio
    // ================================================================================
    // ================================================================================
    public void SetupRadio(View rootview) {
        //Get Radio Group
        rgFunctions = rootview.findViewById(R.id.rgFunctions);

        //Get Radio Buttons
        rbSpeakAll = rootview.findViewById(R.id.rbSpeakAll);
        rbSpeakLastSentence = rootview.findViewById(R.id.rbSpeakLastSentence);

        //Set Event Handlers
        rbSpeakAll.setOnClickListener(RadioClickListener);
        rbSpeakLastSentence.setOnClickListener(RadioClickListener);

        //Toggle Radio Buttons
        ToggleRadioButtons(settings.getBoolean(UserSettings.CUSTOM_MESSAGE_WINDOW, UserSettings.DEFAULT_MESSAGE_WINDOW));
    }
    // endregion Setup



    // region Events
    // Checked Change Listener
    // ================================================================================
    // ================================================================================
    private Switch.OnCheckedChangeListener CheckedChangeListener = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            //Toggle Radio Buttons
            ToggleRadioButtons(isChecked);

            //Validate Setting Save
            if(settings.getBoolean(UserSettings.CUSTOM_MESSAGE_WINDOW, UserSettings.DEFAULT_MESSAGE_WINDOW) != isChecked){
                //Save Setting
                settings.setBoolean(UserSettings.CUSTOM_MESSAGE_WINDOW, isChecked);
            }
        }
    };


    // Radio Click Listener
    // ================================================================================
    // ================================================================================
    private View.OnClickListener RadioClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            //Loop Through Radio Group
            for(int i = 0; i < rgFunctions.getChildCount(); i++){
                //Get Current Looped Radio Button
                RadioButton button = (RadioButton)rgFunctions.getChildAt(i);

                //Validate Check
                if(button.isChecked()){
                    //Save Setting
                    settings.setString(UserSettings.CUSTOM_MESSAGE_WINDOW_FUNCTION, button.getText().toString());
                }
            }
        }
    };
    // endregion Events



    // region Methods
    // Toggle Radio Buttons
    // ================================================================================
    // ================================================================================
    public void ToggleRadioButtons(Boolean isEnabled){
        //Get Radio Button Setting
        String function = settings.getString(UserSettings.CUSTOM_MESSAGE_WINDOW_FUNCTION, UserSettings.DEFAULT_MESSAGE_WINDOW_FUNCTION);

        //Loop Through Radio Group
        for(int i = 0; i < rgFunctions.getChildCount(); i++){
            //Get Current Looped Radio Button
            RadioButton button = (RadioButton)rgFunctions.getChildAt(i);

            //Disable Current Looped Radio Button
            button.setEnabled(isEnabled);

            //Validate Function Setting
            if(function.equals(button.getText())){
                //Check Radio Button
                button.setChecked(true);
            }
        }


        //Validate Mode
        if(isEnabled){
            //Set Background
            rgFunctions.setBackground(getResources().getDrawable(R.drawable.settings_background));
        }
        else{
            //Set Background
            rgFunctions.setBackground(getResources().getDrawable(R.drawable.message_window_background));
        }
    }
    // endregion Methods
}