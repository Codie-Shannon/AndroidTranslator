package com.example.texttospeech;

import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import java.util.List;

public class Fragments{
    // region Internal Variables
    // Button
    // ================================================================================
    // ================================================================================
    private Button button;


    // Image Button
    // ================================================================================
    // ================================================================================
    private ImageButton imageButton;


    // Container View ID
    // ================================================================================
    // ================================================================================
    private int containerViewId;


    // Fragment Class
    // ================================================================================
    // ================================================================================
    private Class<? extends androidx.fragment.app.Fragment> fragmentClass;
    // endregion Internal Variables



    // region External Variables
    // Header
    // ================================================================================
    // ================================================================================
    public static TextView header;
    // endregion Variables



    // Constructor
    // ================================================================================
    // ================================================================================
    public Fragments(Button button, ImageButton imageButton, int containerviewid, Class<? extends androidx.fragment.app.Fragment> fragmentclass) {
        //Set Variables
        this.button = button;
        this.imageButton = imageButton;
        this.containerViewId = containerviewid;
        this.fragmentClass = fragmentclass;
    }



    // region Internal Methods
    // Get Button
    // ================================================================================
    // ================================================================================
    public Button getButton() { return this.button; }
    // endregion Internal Methods



    // region External Methods
    // Set Event Handlers
    // ================================================================================
    // ================================================================================
    public static void SetEventHandlers(FragmentManager fragmentManager, List<Fragments> fragments){
        //Loop Through Fragments
        for (int i = 0; i < fragments.size(); i++) {
            //Get Current Looped Fragment
            Fragments fragment = fragments.get(i);

            //Get Button
            Button button = fragment.button;

            //Set Click Listener
            button.setOnClickListener(view -> {
                //Set Fragment
                setFragment(fragmentManager, button.getText().toString(), fragment.containerViewId, fragment.fragmentClass);
            });
        }
    }


    // Set Event Handler
    // ================================================================================
    // ================================================================================
    public static void SetEventHandler(FragmentManager fragmentManager, Fragments fragment){
        //Get Button
        ImageButton button = fragment.imageButton;

        //Set Click Listener
        button.setOnClickListener(view -> {
            //Set Fragment
            Fragments.setFragment(fragmentManager, "", fragment.containerViewId, fragment.fragmentClass);

            //Check if Button is Sidebar Settings Button
            if(fragment.fragmentClass == SettingsFragment.class){
                //Stop Speaking
                TextFragment.StopSpeaking();
            }
        });
    }


    // Set Back Button
    // ================================================================================
    // ================================================================================
    public static void SetBackButton(FragmentManager mainFragmentManager, FragmentManager childFragmentManager, ImageButton imageButton, int containerViewId, Class<? extends androidx.fragment.app.Fragment> fragmentClass) {
        //Set Click Listener
        imageButton.setOnClickListener(view -> {
            //Validate Back Click
            if (childFragmentManager.getBackStackEntryCount() == 0) {
                //Set Fragment
                Fragments.setFragment(mainFragmentManager, "Settings", containerViewId, fragmentClass);
            } else {
                //Go Back One Page
                childFragmentManager.popBackStack();

                //Set Header
                header.setText(childFragmentManager.getBackStackEntryCount() == 1 ? "Settings" : childFragmentManager.getBackStackEntryAt(0).getName());
            }
        });
    }


    // Set Fragment
    // ================================================================================
    // ================================================================================
    public static void setFragment(FragmentManager fragmentManager, String name, @IdRes int containerViewId, @NonNull Class<? extends androidx.fragment.app.Fragment> fragmentClass) {
        //Set Header
        if(header != null) { header.setText(name); }

        //Initialize Fragment Transaction Object
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        //Set Fragment
        fragmentTransaction.replace(containerViewId, fragmentClass, null).setReorderingAllowed(true);

        //Add Fragment to Back Stack
        fragmentTransaction.addToBackStack(name);

        //Commit Changes
        fragmentTransaction.commit();
    }


    // Get Button
    // ================================================================================
    // ================================================================================
    public static Button getButton(View rootview, int id) { return rootview.findViewById(id); }


    // Get Image Button
    // ================================================================================
    // ================================================================================
    public static ImageButton getImageButton(View rootview, int id) { return rootview.findViewById(id); }
    // endregion External Methods
}