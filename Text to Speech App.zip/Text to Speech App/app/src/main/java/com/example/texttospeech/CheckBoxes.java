package com.example.texttospeech;

import android.widget.Button;
import android.widget.CheckBox;
import androidx.appcompat.app.AppCompatDelegate;
import java.util.List;

public class CheckBoxes {
    // region Internal Variables
    // Name
    // ================================================================================
    // ================================================================================
    private String name;


    // Key
    // ================================================================================
    // ================================================================================
    private String Key;


    // Button
    // ================================================================================
    // ================================================================================
    private Button button;


    // CheckBox
    // ================================================================================
    // ================================================================================
    private CheckBox checkBox;


    // Default Value
    // ================================================================================
    // ================================================================================
    private String DefaultValue;
    // endregion Internal Variables



    // Constructor
    // ================================================================================
    // ================================================================================
    public CheckBoxes(String name, String key, Button button, CheckBox checkbox, String defaultvalue) {
        //Set Variables
        this.name = name;
        this.Key = key;
        this.button = button;
        this.checkBox = checkbox;
        this.DefaultValue = defaultvalue;
    }



    // Setup
    // ================================================================================
    // ================================================================================
    public static void Setup(String type, List<CheckBoxes> checkboxes, UserSettings settings, String key, String defaultvalue){
        //Set Event Handlers
        SetEventHandlers(type, checkboxes, settings);

        //Set CheckBox
        SetCheckBox(false, type, settings.getString(key, defaultvalue), checkboxes, settings);
    }



    // region Internal Methods
    // Get Name
    // ================================================================================
    // ================================================================================
    public String getName() { return this.name; }


    // Get Key
    // ================================================================================
    // ================================================================================
    public String getKey() { return this.Key; }


    // Get Button
    // ================================================================================
    // ================================================================================
    public Button getButton() { return this.button; }


    // Get CheckBox
    // ================================================================================
    // ================================================================================
    public CheckBox getCheckBox() { return this.checkBox; }
    // endregion Internal Methods



    // region External Methods
    // Set Event Handlers
    // ================================================================================
    // ================================================================================
    public static void SetEventHandlers(String type, List<CheckBoxes> checkboxes, UserSettings settings){
        //Loop Through CheckBoxes
        for (int i = 0; i < checkboxes.size(); i++) {
            //Get Current Looped CheckBox
            CheckBoxes checkbox = checkboxes.get(i);

            //Set Click Listener
            checkbox.getButton().setOnClickListener(view -> {
                //Set CheckBox
                SetCheckBox(true, type, checkbox.name, checkboxes, settings);
            });
        }
    }


    // Set CheckBox
    // ================================================================================
    // ================================================================================
    private static void SetCheckBox(Boolean isSave, String type, String name, List<CheckBoxes> checkboxes, UserSettings settings) {
        //Loop Through Checkboxes
        for (int i = 0; i < checkboxes.size(); i++) {
            //Get Current Looped CheckBox
            CheckBoxes checkbox = checkboxes.get(i);

            //Validate Check
            if (!checkbox.getName().equals(name)) {
                //Uncheck Current Looped CheckBox
                checkbox.getCheckBox().setChecked(false);
            }
            else {
                //Check Current Looped CheckBox
                while(!checkbox.getCheckBox().isChecked()) { checkbox.getCheckBox().setChecked(true); }

                //Validate Setting Save
                if (isSave && checkbox.getName() != settings.getString(checkbox.getKey(), checkbox.DefaultValue)) {
                    //Save Setting
                    settings.setString(checkbox.getKey(), checkbox.getName().toLowerCase());

                    //Check if the CheckBox Type is Themes
                    if(type.equals("themes")) {
                        //Set Theme
                        AppCompatDelegate.setDefaultNightMode(checkbox.getName().equals(UserSettings.DEFAULT_THEME) ? AppCompatDelegate.MODE_NIGHT_NO : AppCompatDelegate.MODE_NIGHT_YES);
                    }
                }
            }
        }
    }
    // endregion External Methods
}