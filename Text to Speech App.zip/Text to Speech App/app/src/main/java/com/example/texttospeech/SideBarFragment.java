package com.example.texttospeech;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class SideBarFragment extends Fragment {
    // Useless
    // ================================================================================
    // ================================================================================
    public SideBarFragment() { /* Required empty public constructor */ }


    // New Instance
    // ================================================================================
    // ================================================================================
    public static SideBarFragment newInstance() { return new SideBarFragment(); }


    // onCreate
    // ================================================================================
    // ================================================================================
    @Override
    public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); }


    // onCreateView
    // ================================================================================
    // ================================================================================
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_sidebar, container, false);

        // Set Navigation
        SetNavigation(rootView);

        // Set Delete All Event Handler (Clear Input Field)
        rootView.findViewById(R.id.btnDeleteAll).setOnClickListener(view -> { TextFragment.DeleteAll(getActivity()); });

        // Set Speak Event Handler (Speak Input Field Text)
        rootView.findViewById(R.id.btnSpeak).setOnClickListener(view -> { TextFragment.Speak(TextFragment.Get(), false); });

        // Return RootView
        return rootView;
    }


    // Set Navigation
    // ================================================================================
    // ================================================================================
    public void SetNavigation(View rootview) {
        //Initialize Fragment Object
        Fragments fragment = new Fragments(null, Fragments.getImageButton(rootview, R.id.btnSettings), R.id.fragMain, SettingsFragment.class);

        //Set Event Handler
        Fragments.SetEventHandler(((MainActivity)getActivity()).getSupportFragmentManager(), fragment);
    }
}