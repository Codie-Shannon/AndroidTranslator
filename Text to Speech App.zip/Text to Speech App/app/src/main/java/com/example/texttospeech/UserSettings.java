package com.example.texttospeech;

import android.app.Application;
import android.content.SharedPreferences;

public class UserSettings extends Application {
    // region Variables
    // Shared Preferences
    // ================================================================================
    // ================================================================================
    public static final String PREFERENCES = "preferences";
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;



    // region Stats
    // Speak
    // ================================================================================
    // ================================================================================
    public static final String CUSTOM_SPEAK_STAT = "customSpeakStat";


    // Phrases
    // ================================================================================
    // ================================================================================
    public static final String CUSTOM_PHRASES_STAT = "customSpeakStat";


    // Average Sentence Length
    // ================================================================================
    // ================================================================================
    public static final String CUSTOM_AVERAGE_SENTENCE_LENGTH_STAT = "customAverageSentenceLengthStat";
    // endregion Stats



    // region Keyboard
    // Keyboard Type
    // ================================================================================
    // ================================================================================
    public static final String CUSTOM_KEYBOARD = "customKeyboard";
    public static final String CUSTOM_KEYBOARD_ID = "customKeyboardID";
    public static final String DEFAULT_KEYBOARD = "QWERTY";
    public static final String QWERTY_KEYBOARD = "QWERTY";
    // endregion Keyboard



    // region Speech
    // Clear After Speak
    // ================================================================================
    // ================================================================================
    public static final String CUSTOM_CLEAR_AFTER_SPEAK = "customClearAfterSpeak";
    public static final Boolean DEFAULT_CLEAR_AFTER_SPEAK = false;


    // Speak Phrases on Tap
    // ================================================================================
    // ================================================================================
    public static final String CUSTOM_SPEAK_PHRASES_ON_TAP = "customSpeakPhrasesOnTap";
    public static final Boolean DEFAULT_SPEAK_PHRASES_ON_TAP = false;


    // Speech Rate
    // ================================================================================
    // ================================================================================
    public static final String CUSTOM_SPEAK_RATE = "customSpeakRate";


    // Speak Pitch
    // ================================================================================
    // ================================================================================
    public static final String CUSTOM_SPEAK_PITCH = "customSpeakPitch";
    // endregion Speech



    // region Message Window (Speech > Advanced)
    // Mode
    // ================================================================================
    // ================================================================================
    public static final String CUSTOM_MESSAGE_WINDOW = "customMessageWindow";
    public static final Boolean DEFAULT_MESSAGE_WINDOW = false;


    // Function
    // ================================================================================
    // ================================================================================
    public static final String CUSTOM_MESSAGE_WINDOW_FUNCTION = "customMessageWindowFunction";
    public static final String DEFAULT_MESSAGE_WINDOW_FUNCTION = "Speak All";
    public static final String SPEAK_ALL_MESSAGE_WINDOW_FUNCTION = "Speak All";
    // endregion Message Window



    // region Device Voice
    // Genders
    // ================================================================================
    // ================================================================================
    public static final String CUSTOM_GENDER = "customGender";
    public static final String DEFAULT_GENDER = "male";
    public static final String MALE_GENDER = "male";
    public static final String FEMALE_GENDER = "female";


    // Languages
    // ================================================================================
    // ================================================================================
    public static final String CUSTOM_LANGUAGE = "customLanguage";
    public static final String DEFAULT_LANGUAGE = "australian";
    public static final String AUSTRALIAN_LANGUAGE = "australian";
    public static final String AMERICAN_LANGUAGE = "american";
    // endregion Device Voice



    // region Themes
    // Themes
    // ================================================================================
    // ================================================================================
    public static final String CUSTOM_THEME = "customTheme";
    public static final String DEFAULT_THEME = "light";
    public static final String LIGHT_THEME = "light";
    public static final String DARK_THEME = "dark";
    // endregion Themes
    // endregion Variables




    // region Methods
    // Setup
    // ================================================================================
    // ================================================================================
    public void SetUp(){
        //Get Shared Preferences
        getPreferences();

        //Get Shared Preferences Editor
        getEditor();
    }



    // region Get Methods
    // Preferences
    // ================================================================================
    // ================================================================================
    public void getPreferences() { sharedPreferences = getApplicationContext().getSharedPreferences(PREFERENCES, MODE_PRIVATE); }


    // Editor
    // ================================================================================
    // ================================================================================
    public void getEditor() { editor = sharedPreferences.edit(); }


    // Integer
    // ================================================================================
    // ================================================================================
    public int getInteger(String key, int defaultValue) { return sharedPreferences.getInt(key, defaultValue); }


    // Boolean
    // ================================================================================
    // ================================================================================
    public boolean getBoolean(String key, boolean defaultValue) { return sharedPreferences.getBoolean(key, defaultValue); }


    // String
    // ================================================================================
    // ================================================================================
    public String getString(String key, String defaultValue) { return sharedPreferences.getString(key, defaultValue); }
    // endregion Get Methods



    // region Set Methods
    // Integer
    // ================================================================================
    // ================================================================================
    public void setInteger(String key, int value) { editor.putInt(key, value); editor.apply(); }


    // Boolean
    // ================================================================================
    // ================================================================================
    public void setBoolean(String key, Boolean value) { editor.putBoolean(key, value); editor.apply(); }


    // String
    // ================================================================================
    // ================================================================================
    public void setString(String key, String value) { editor.putString(key, value); editor.apply(); }
    // endregion Set Methods
    // endregion Methods
}